import { PricingCards } from "@/components/pricing-cards";

type SearchParams = Promise<{ payment?: string }>;

export default async function PricingPage({ searchParams }: { searchParams: SearchParams }) {
  const { payment } = await searchParams;
  return (
    <main className="page">
      <div className="container">
        <div className="section-head">
          <span className="eyebrow">Bảng giá minh bạch</span>
          <h1 style={{ fontSize: 54 }}>Mở khóa trợ lý AI của bạn</h1>
          <p>Thanh toán an toàn, kích hoạt tự động và có thể gia hạn hoặc quản lý gói bất cứ lúc nào.</p>
        </div>
        {payment === "cancelled" && <div className="notice" style={{ maxWidth: 760, margin: "0 auto 24px" }}>Thanh toán đã được hủy. Tài khoản chưa bị tính phí và bạn có thể chọn lại gói khi sẵn sàng.</div>}
        <PricingCards />
      </div>
    </main>
  );
}
