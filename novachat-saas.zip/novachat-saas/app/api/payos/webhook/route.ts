import { NextResponse } from "next/server";
import { getPayOS } from "@/lib/payos";
import { createAdminClient } from "@/lib/supabase/admin";

export const runtime = "nodejs";

export async function POST(request: Request) {
  try {
    const payload = await request.json();
    const verified = await getPayOS().webhooks.verify(payload) as {
      orderCode: number;
      amount: number;
      reference?: string;
      code?: string;
    };

    if (verified.code && verified.code !== "00") {
      return NextResponse.json({ received: true });
    }

    const { data, error } = await createAdminClient().rpc("activate_payos_order", {
      p_order_code: verified.orderCode,
      p_amount: verified.amount,
      p_reference: verified.reference || "",
    });
    if (error) throw error;

    return NextResponse.json({ received: true, activated: Boolean(data) });
  } catch (error) {
    console.error("payos_webhook_error", error);
    return NextResponse.json({ error: "Webhook không hợp lệ" }, { status: 400 });
  }
}
