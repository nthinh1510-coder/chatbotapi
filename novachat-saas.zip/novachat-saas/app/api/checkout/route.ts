import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { getStripe } from "@/lib/stripe";
import { getPayOS } from "@/lib/payos";
import { getPaymentProvider } from "@/lib/payment";
import { getPlan, getStripePriceId, type PlanId } from "@/lib/plans";
import { siteConfig } from "@/lib/site";

export async function POST(request: Request) {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: "Bạn cần đăng nhập" }, { status: 401 });

    const { planId } = await request.json() as { planId?: PlanId };
    const plan = getPlan(planId);
    if (!plan) return NextResponse.json({ error: "Gói không hợp lệ" }, { status: 400 });

    const provider = getPaymentProvider();
    const admin = createAdminClient();

    if (provider === "payos") {
      const orderCode = Date.now() * 1000 + Math.floor(Math.random() * 1000);
      const description = `NC ${plan.id.toUpperCase()} ${String(orderCode).slice(-6)}`;

      const { error: orderError } = await admin.from("payment_orders").insert({
        order_code: orderCode,
        user_id: user.id,
        plan_id: plan.id,
        amount: plan.amountVnd,
        duration_days: plan.durationDays,
        status: "pending",
        provider: "payos",
      });
      if (orderError) throw orderError;

      const paymentLink = await getPayOS().paymentRequests.create({
        orderCode,
        amount: plan.amountVnd,
        description,
        items: [{ name: `Gói ${plan.name}`, quantity: 1, price: plan.amountVnd }],
        cancelUrl: `${siteConfig.url}/pricing?payment=cancelled`,
        returnUrl: `${siteConfig.url}/payment/success?orderCode=${orderCode}`,
      });

      return NextResponse.json({ url: paymentLink.checkoutUrl });
    }

    const priceId = getStripePriceId(plan.id);
    if (!priceId) return NextResponse.json({ error: `Chưa cấu hình Stripe Price ID cho gói ${plan.name}` }, { status: 500 });

    const stripe = getStripe();
    const { data: existing } = await admin
      .from("subscriptions")
      .select("stripe_customer_id,status,provider")
      .eq("user_id", user.id)
      .maybeSingle();

    let customerId = existing?.stripe_customer_id as string | null;
    if (existing?.provider === "stripe" && existing?.status && ["active", "trialing"].includes(existing.status) && customerId) {
      const portal = await stripe.billingPortal.sessions.create({
        customer: customerId,
        return_url: `${siteConfig.url}/chat`,
      });
      return NextResponse.json({ url: portal.url });
    }

    if (!customerId) {
      const customer = await stripe.customers.create({
        email: user.email,
        metadata: { user_id: user.id },
      });
      customerId = customer.id;
      if (existing) {
        await admin.from("subscriptions").update({
          stripe_customer_id: customerId,
          updated_at: new Date().toISOString(),
        }).eq("user_id", user.id);
      } else {
        await admin.from("subscriptions").insert({
          user_id: user.id,
          stripe_customer_id: customerId,
          status: "inactive",
          provider: "stripe",
          updated_at: new Date().toISOString(),
        });
      }
    }

    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      customer: customerId,
      line_items: [{ price: priceId, quantity: 1 }],
      success_url: `${siteConfig.url}/chat?payment=success`,
      cancel_url: `${siteConfig.url}/pricing?payment=cancelled`,
      allow_promotion_codes: true,
      metadata: { user_id: user.id, plan_id: plan.id },
      subscription_data: { metadata: { user_id: user.id, plan_id: plan.id } },
    });

    return NextResponse.json({ url: session.url });
  } catch (error) {
    console.error("checkout_error", error);
    return NextResponse.json({ error: "Không thể khởi tạo thanh toán" }, { status: 500 });
  }
}
