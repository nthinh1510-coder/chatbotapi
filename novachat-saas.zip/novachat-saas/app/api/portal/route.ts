import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { getStripe } from "@/lib/stripe";
import { siteConfig } from "@/lib/site";

export async function POST() {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: "Bạn cần đăng nhập" }, { status: 401 });

    const { data } = await createAdminClient()
      .from("subscriptions")
      .select("provider,stripe_customer_id")
      .eq("user_id", user.id)
      .maybeSingle();

    if (data?.provider !== "stripe") {
      return NextResponse.json({ url: `${siteConfig.url}/pricing` });
    }
    if (!data.stripe_customer_id) {
      return NextResponse.json({ error: "Chưa có thông tin thanh toán Stripe" }, { status: 404 });
    }

    const session = await getStripe().billingPortal.sessions.create({
      customer: data.stripe_customer_id,
      return_url: `${siteConfig.url}/chat`,
    });
    return NextResponse.json({ url: session.url });
  } catch (error) {
    console.error("portal_error", error);
    return NextResponse.json({ error: "Không thể mở trang quản lý gói" }, { status: 500 });
  }
}
