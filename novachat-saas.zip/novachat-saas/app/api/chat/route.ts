import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { getActiveSubscription } from "@/lib/subscription";
import { getPlan } from "@/lib/plans";
import { getOpenAI } from "@/lib/openai";

export const runtime = "nodejs";

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

async function authenticate() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  return user;
}

export async function GET(request: Request) {
  try {
    const user = await authenticate();
    if (!user) return NextResponse.json({ error: "Bạn cần đăng nhập" }, { status: 401 });

    const threadId = new URL(request.url).searchParams.get("threadId");
    if (!threadId) return NextResponse.json({ error: "Thiếu threadId" }, { status: 400 });
    if (!UUID_PATTERN.test(threadId)) return NextResponse.json({ error: "threadId không hợp lệ" }, { status: 400 });

    const admin = createAdminClient();
    const { data: thread } = await admin
      .from("chat_threads")
      .select("id,title")
      .eq("id", threadId)
      .eq("user_id", user.id)
      .maybeSingle();

    if (!thread) return NextResponse.json({ error: "Không tìm thấy cuộc trò chuyện" }, { status: 404 });

    const { data: messages, error } = await admin
      .from("chat_messages")
      .select("id,role,content,created_at")
      .eq("thread_id", threadId)
      .eq("user_id", user.id)
      .order("created_at", { ascending: true });
    if (error) throw error;

    return NextResponse.json({ thread, messages: messages || [] });
  } catch (error) {
    console.error("chat_get_error", error);
    return NextResponse.json({ error: "Không thể tải cuộc trò chuyện" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  let quotaConsumed = false;
  let userId = "";

  try {
    const user = await authenticate();
    if (!user) return NextResponse.json({ error: "Bạn cần đăng nhập" }, { status: 401 });
    userId = user.id;

    const subscription = await getActiveSubscription(user.id);
    if (!subscription) {
      return NextResponse.json(
        { error: "Bạn cần mua hoặc gia hạn gói để sử dụng chatbot", code: "SUBSCRIPTION_REQUIRED" },
        { status: 403 },
      );
    }

    const plan = getPlan(subscription.plan_id);
    if (!plan) return NextResponse.json({ error: "Gói hiện tại chưa được cấu hình" }, { status: 500 });

    const payload = await request.json() as { message?: string; threadId?: string | null };
    const message = payload.message?.trim();
    if (!message || message.length > 12000) {
      return NextResponse.json({ error: "Nội dung không hợp lệ hoặc quá dài" }, { status: 400 });
    }

    const admin = createAdminClient();
    let threadId = payload.threadId || null;
    if (threadId && !UUID_PATTERN.test(threadId)) {
      return NextResponse.json({ error: "threadId không hợp lệ" }, { status: 400 });
    }
    let previousResponseId: string | null = null;
    let title = message.slice(0, 54) + (message.length > 54 ? "…" : "");

    // Validate ownership before consuming quota.
    if (threadId) {
      const { data: thread } = await admin
        .from("chat_threads")
        .select("id,title,openai_previous_response_id")
        .eq("id", threadId)
        .eq("user_id", user.id)
        .maybeSingle();
      if (!thread) return NextResponse.json({ error: "Cuộc trò chuyện không hợp lệ" }, { status: 404 });
      previousResponseId = thread.openai_previous_response_id;
      title = thread.title;
    }

    const { data: quotaRows, error: quotaError } = await admin.rpc("consume_message_quota", {
      p_user_id: user.id,
      p_limit: plan.messageLimit,
    });
    if (quotaError) throw quotaError;

    const quota = Array.isArray(quotaRows) ? quotaRows[0] : quotaRows;
    if (!quota?.allowed) {
      return NextResponse.json(
        { error: "Bạn đã dùng hết hạn mức tin nhắn trong tháng", code: "QUOTA_EXCEEDED", used: quota?.used },
        { status: 429 },
      );
    }
    quotaConsumed = true;

    const vectorStoreId = process.env.OPENAI_VECTOR_STORE_ID;
    const response = await getOpenAI().responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.6-terra",
      instructions: process.env.CHATBOT_SYSTEM_PROMPT || "Bạn là trợ lý AI hữu ích. Hãy trả lời rõ ràng bằng tiếng Việt.",
      input: message,
      previous_response_id: previousResponseId || undefined,
      tools: vectorStoreId ? [{ type: "file_search", vector_store_ids: [vectorStoreId] }] : undefined,
    });

    const answer = response.output_text?.trim() || "Xin lỗi, tôi chưa thể tạo câu trả lời lúc này.";

    if (!threadId) {
      const { data: createdThread, error: threadError } = await admin
        .from("chat_threads")
        .insert({ user_id: user.id, title, openai_previous_response_id: response.id })
        .select("id")
        .single();
      if (threadError) throw threadError;
      threadId = createdThread.id;
    }

    const finalThreadId = threadId;
    const { error: insertError } = await admin.from("chat_messages").insert([
      { thread_id: finalThreadId, user_id: user.id, role: "user", content: message },
      { thread_id: finalThreadId, user_id: user.id, role: "assistant", content: answer },
    ]);
    if (insertError) throw insertError;

    await admin
      .from("chat_threads")
      .update({ openai_previous_response_id: response.id, updated_at: new Date().toISOString() })
      .eq("id", finalThreadId)
      .eq("user_id", user.id);

    return NextResponse.json({ threadId: finalThreadId, title, answer, used: quota.used });
  } catch (error) {
    console.error("chat_post_error", error);
    if (quotaConsumed && userId) {
      try {
        await createAdminClient().rpc("refund_message_quota", { p_user_id: userId });
      } catch {
        // Best-effort compensation only.
      }
    }
    return NextResponse.json({ error: "Chatbot đang bận. Vui lòng thử lại." }, { status: 500 });
  }
}
