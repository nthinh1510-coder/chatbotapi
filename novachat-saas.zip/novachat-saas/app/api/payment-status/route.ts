import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";

export async function GET(request: Request) {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: "Bạn cần đăng nhập" }, { status: 401 });

    const orderCode = new URL(request.url).searchParams.get("orderCode");
    if (!orderCode || !/^\d+$/.test(orderCode)) {
      return NextResponse.json({ error: "Mã đơn hàng không hợp lệ" }, { status: 400 });
    }

    const { data, error } = await createAdminClient()
      .from("payment_orders")
      .select("status,plan_id,paid_at")
      .eq("order_code", orderCode)
      .eq("user_id", user.id)
      .maybeSingle();
    if (error) throw error;
    if (!data) return NextResponse.json({ error: "Không tìm thấy đơn hàng" }, { status: 404 });

    return NextResponse.json(data);
  } catch (error) {
    console.error("payment_status_error", error);
    return NextResponse.json({ error: "Không thể kiểm tra thanh toán" }, { status: 500 });
  }
}
