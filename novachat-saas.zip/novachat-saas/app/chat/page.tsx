import Link from "next/link";
import { redirect } from "next/navigation";
import { LockKeyhole } from "lucide-react";
import { requireUser } from "@/lib/auth";
import { createAdminClient } from "@/lib/supabase/admin";
import { getActiveSubscription } from "@/lib/subscription";
import { getPlan } from "@/lib/plans";
import { ChatShell } from "@/components/chat-shell";

export const dynamic = "force-dynamic";

type SearchParams = Promise<{ thread?: string; payment?: string }>;

export default async function ChatPage({ searchParams }: { searchParams: SearchParams }) {
  const user = await requireUser();
  const subscription = await getActiveSubscription(user.id);
  const params = await searchParams;

  if (!subscription) {
    return (
      <main className="page">
        <div className="container" style={{ maxWidth: 720 }}>
          <div className="panel" style={{ padding: 38, textAlign: "center" }}>
            <div className="icon-box" style={{ margin: "0 auto" }}><LockKeyhole /></div>
            <h1 style={{ fontSize: 40, letterSpacing: -1.4 }}>Cần gói đang hoạt động</h1>
            <p style={{ color: "#9fb0c8", lineHeight: 1.7 }}>Tài khoản của bạn chưa có thuê bao hợp lệ. Hãy chọn một gói để mở khóa chatbot.</p>
            <Link className="btn btn-primary" href="/pricing">Xem bảng giá</Link>
          </div>
        </div>
      </main>
    );
  }

  const plan = getPlan(subscription.plan_id);
  if (!plan) redirect("/pricing");

  const admin = createAdminClient();
  const { data: threads } = await admin
    .from("chat_threads")
    .select("id,title,updated_at")
    .eq("user_id", user.id)
    .order("updated_at", { ascending: false })
    .limit(30);

  const threadList = threads || [];
  const selectedThreadId = params.thread && threadList.some((t) => t.id === params.thread)
    ? params.thread
    : threadList[0]?.id || null;

  let initialMessages: Array<{ id: string; role: "user" | "assistant"; content: string; created_at: string }> = [];
  if (selectedThreadId) {
    const { data } = await admin
      .from("chat_messages")
      .select("id,role,content,created_at")
      .eq("thread_id", selectedThreadId)
      .eq("user_id", user.id)
      .order("created_at", { ascending: true });
    initialMessages = (data || []) as typeof initialMessages;
  }

  const monthStart = new Date();
  monthStart.setUTCDate(1);
  monthStart.setUTCHours(0, 0, 0, 0);
  const { data: usage } = await admin
    .from("usage_monthly")
    .select("message_count")
    .eq("user_id", user.id)
    .eq("month_start", monthStart.toISOString().slice(0, 10))
    .maybeSingle();

  const used = usage?.message_count || 0;
  return (
    <main>
      {params.payment === "success" && <div className="container" style={{ paddingTop: 16 }}><div className="form-success">Thanh toán thành công. Gói của bạn đã được kích hoạt.</div></div>}
      <ChatShell
        initialThreads={threadList}
        initialThreadId={selectedThreadId}
        initialMessages={initialMessages}
        planName={plan.name}
        initialUsed={used}
        messageLimit={plan.messageLimit}
      />
    </main>
  );
}
