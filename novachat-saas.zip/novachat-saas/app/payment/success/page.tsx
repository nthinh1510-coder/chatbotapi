import { redirect } from "next/navigation";
import { requireUser } from "@/lib/auth";
import { PaymentStatus } from "@/components/payment-status";

export const dynamic = "force-dynamic";

type SearchParams = Promise<{ orderCode?: string }>;

export default async function PaymentSuccessPage({ searchParams }: { searchParams: SearchParams }) {
  await requireUser();
  const { orderCode } = await searchParams;
  if (!orderCode || !/^\d+$/.test(orderCode)) redirect("/pricing");

  return (
    <main className="page">
      <div className="container" style={{ maxWidth: 700 }}>
        <PaymentStatus orderCode={orderCode} />
      </div>
    </main>
  );
}
