import Link from "next/link";
import { ArrowRight, Bot, CheckCircle2, LockKeyhole, MessagesSquare, ShieldCheck, Sparkles, Zap } from "lucide-react";
import { PricingCards } from "@/components/pricing-cards";

export default function HomePage() {
  return (
    <main>
      <section className="hero">
        <div className="container hero-grid">
          <div>
            <div className="eyebrow"><Sparkles size={15}/> Nền tảng chatbot AI dành riêng cho khách hàng của bạn</div>
            <h1><span className="gradient-text">Trò chuyện thông minh.</span><br/>Truy cập theo gói.</h1>
            <p className="hero-copy">
              Một website SaaS hiện đại giúp người dùng đăng ký, thanh toán gói và truy cập chatbot AI của bạn trong môi trường an toàn, dễ sử dụng.
            </p>
            <div className="hero-actions">
              <Link className="btn btn-primary" href="/pricing">Xem các gói <ArrowRight size={17}/></Link>
              <Link className="btn btn-secondary" href="/login">Đăng nhập</Link>
            </div>
            <div className="hero-note">Không lộ API key · Phân quyền tự động · Quản lý hạn mức theo tháng</div>
          </div>
          <div className="preview" aria-label="Xem trước giao diện chatbot">
            <div className="preview-window">
              <div className="preview-top"><span className="dot"/><span className="dot"/><span className="dot"/></div>
              <div className="preview-body">
                <div className="preview-title">Trợ lý Nova</div>
                <div className="bubble bubble-ai">Xin chào! Tôi có thể hỗ trợ bạn tìm thông tin, phân tích và giải đáp câu hỏi.</div>
                <div className="bubble bubble-user">Hãy giúp tôi lập kế hoạch công việc tuần này.</div>
                <div className="bubble bubble-ai">Được. Tôi sẽ chia kế hoạch theo mức độ ưu tiên, thời hạn và thời gian dự kiến để bạn dễ thực hiện.</div>
                <div className="preview-input"><span>Nhập câu hỏi của bạn...</span><span>↗</span></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="section" id="features">
        <div className="container">
          <div className="section-head">
            <h2>Mọi thành phần cần thiết để bán quyền truy cập AI</h2>
            <p>Luồng người dùng được thiết kế liền mạch từ đăng ký, mua gói đến sử dụng chatbot và quản lý thuê bao.</p>
          </div>
          <div className="grid-3">
            <div className="feature-card"><div className="icon-box"><LockKeyhole/></div><h3>Truy cập có kiểm soát</h3><p>Chỉ tài khoản có thuê bao đang hoạt động mới sử dụng được chatbot.</p></div>
            <div className="feature-card"><div className="icon-box"><Zap/></div><h3>Thanh toán tự động</h3><p>payOS/VietQR hoặc Stripe, webhook cập nhật gói và kích hoạt quyền truy cập tự động.</p></div>
            <div className="feature-card"><div className="icon-box"><MessagesSquare/></div><h3>Lịch sử hội thoại</h3><p>Lưu cuộc trò chuyện theo từng người dùng và tiếp tục ngữ cảnh qua Responses API.</p></div>
            <div className="feature-card"><div className="icon-box"><ShieldCheck/></div><h3>Bảo mật phía máy chủ</h3><p>OpenAI key, Stripe secret và Supabase service role không bao giờ gửi xuống trình duyệt.</p></div>
            <div className="feature-card"><div className="icon-box"><Bot/></div><h3>Tùy chỉnh chatbot</h3><p>Thay system prompt, model và kho kiến thức vector store bằng biến môi trường.</p></div>
            <div className="feature-card"><div className="icon-box"><CheckCircle2/></div><h3>Quản trị & hạn mức</h3><p>Theo dõi thuê bao, người dùng và số tin nhắn đã sử dụng trong tháng.</p></div>
          </div>
        </div>
      </section>

      <section className="section" id="pricing">
        <div className="container">
          <div className="section-head"><h2>Chọn gói phù hợp</h2><p>Bạn có thể đổi tên, giá, quyền lợi và hạn mức trong một file cấu hình.</p></div>
          <PricingCards />
        </div>
      </section>

      <section className="section" id="faq">
        <div className="container prose">
          <div className="section-head"><h2>Câu hỏi thường gặp</h2></div>
          <div className="panel" style={{ padding: 26 }}>
            <h3>Chatbot có phải chính là Custom GPT trong ChatGPT không?</h3>
            <p>Website dùng OpenAI API và tái tạo hướng dẫn, kiến thức, quy trình của chatbot ở phía máy chủ. Bạn có thể đưa prompt và kho tài liệu của mình vào cấu hình.</p>
            <h3>Người dùng có nhìn thấy API key không?</h3>
            <p>Không. Mọi lời gọi OpenAI và cổng thanh toán đều đi qua Route Handler phía máy chủ.</p>
            <h3>Có thể đổi cổng thanh toán không?</h3>
            <p>Có. Có. Website đã hỗ trợ payOS/VietQR và Stripe, chọn bằng một biến môi trường.</p>
          </div>
        </div>
      </section>
    </main>
  );
}
