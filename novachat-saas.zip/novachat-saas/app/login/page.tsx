import { LoginForm } from "@/components/login-form";

type SearchParams = Promise<{ next?: string }>;

export default async function LoginPage({ searchParams }: { searchParams: SearchParams }) {
  const { next } = await searchParams;
  return <main className="auth-wrap"><LoginForm nextPath={next} /></main>;
}
