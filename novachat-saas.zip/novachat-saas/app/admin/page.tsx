import { redirect } from "next/navigation";
import { requireUser } from "@/lib/auth";
import { createAdminClient } from "@/lib/supabase/admin";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const user = await requireUser();
  const admin = createAdminClient();
  const { data: profile } = await admin.from("profiles").select("role").eq("id", user.id).maybeSingle();
  if (profile?.role !== "admin") redirect("/chat");

  const monthStart = new Date();
  monthStart.setUTCDate(1);
  monthStart.setUTCHours(0, 0, 0, 0);

  const [usersCount, activeRows, usageRows, subscriptions, profiles] = await Promise.all([
    admin.from("profiles").select("id", { count: "exact", head: true }),
    admin.from("subscriptions").select("user_id,current_period_end,status").in("status", ["active", "trialing"]),
    admin.from("usage_monthly").select("message_count").eq("month_start", monthStart.toISOString().slice(0, 10)),
    admin.from("subscriptions").select("user_id,plan_id,status,current_period_end,updated_at").order("updated_at", { ascending: false }).limit(25),
    admin.from("profiles").select("id,full_name"),
  ]);

  const messages = (usageRows.data || []).reduce((sum, row) => sum + (row.message_count || 0), 0);
  const now = Date.now();
  const activeCount = (activeRows.data || []).filter((item) => !item.current_period_end || new Date(item.current_period_end).getTime() > now).length;
  const profileMap = new Map((profiles.data || []).map((item) => [item.id, item.full_name || "Người dùng"]));

  return (
    <main className="page">
      <div className="container">
        <div className="section-head" style={{ textAlign: "left", margin: 0 }}>
          <span className="eyebrow">Admin dashboard</span>
          <h1 style={{ fontSize: 50 }}>Tổng quan hệ thống</h1>
        </div>
        <div className="stat-grid">
          <div className="panel stat"><div className="stat-label">Tổng người dùng</div><div className="stat-value">{usersCount.count || 0}</div></div>
          <div className="panel stat"><div className="stat-label">Thuê bao hoạt động</div><div className="stat-value">{activeCount}</div></div>
          <div className="panel stat"><div className="stat-label">Tin nhắn tháng này</div><div className="stat-value">{messages}</div></div>
        </div>
        <div className="panel table-wrap">
          <table>
            <thead><tr><th>Người dùng</th><th>Gói</th><th>Trạng thái</th><th>Hết chu kỳ</th></tr></thead>
            <tbody>
              {(subscriptions.data || []).map((sub) => (
                <tr key={sub.user_id}>
                  <td>{profileMap.get(sub.user_id) || sub.user_id.slice(0, 8)}</td>
                  <td>{sub.plan_id || "—"}</td>
                  <td><span className="badge">{sub.status}</span></td>
                  <td>{sub.current_period_end ? new Date(sub.current_period_end).toLocaleDateString("vi-VN") : "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </main>
  );
}
