-- Run this file once in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'user' check (role in ('user', 'admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.subscriptions (
  user_id uuid primary key references auth.users(id) on delete cascade,
  stripe_customer_id text unique,
  stripe_subscription_id text unique,
  status text not null default 'inactive',
  provider text not null default 'stripe' check (provider in ('stripe', 'payos', 'manual')),
  plan_id text,
  current_period_end timestamptz,
  cancel_at_period_end boolean not null default false,
  updated_at timestamptz not null default now()
);

alter table public.subscriptions add column if not exists provider text not null default 'stripe';

do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'subscriptions_provider_check'
      and conrelid = 'public.subscriptions'::regclass
  ) then
    alter table public.subscriptions
      add constraint subscriptions_provider_check
      check (provider in ('stripe', 'payos', 'manual'));
  end if;
end $$;

create table if not exists public.usage_monthly (
  user_id uuid not null references auth.users(id) on delete cascade,
  month_start date not null,
  message_count integer not null default 0 check (message_count >= 0),
  primary key (user_id, month_start)
);


create table if not exists public.payment_orders (
  order_code bigint primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  plan_id text not null,
  amount integer not null check (amount > 0),
  duration_days integer not null default 30 check (duration_days > 0),
  status text not null default 'pending' check (status in ('pending', 'paid', 'cancelled', 'expired')),
  provider text not null default 'payos',
  provider_reference text,
  created_at timestamptz not null default now(),
  paid_at timestamptz
);

create index if not exists payment_orders_user_created_idx on public.payment_orders(user_id, created_at desc);

create table if not exists public.chat_threads (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null default 'Cuộc trò chuyện mới',
  openai_previous_response_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.chat_messages (
  id uuid primary key default gen_random_uuid(),
  thread_id uuid not null references public.chat_threads(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('user', 'assistant')),
  content text not null,
  created_at timestamptz not null default now()
);

create index if not exists chat_threads_user_updated_idx on public.chat_threads(user_id, updated_at desc);
create index if not exists chat_messages_thread_created_idx on public.chat_messages(thread_id, created_at asc);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'full_name', ''))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.consume_message_quota(p_user_id uuid, p_limit integer)
returns table(allowed boolean, used integer)
language plpgsql
security definer set search_path = public
as $$
declare
  v_month date := date_trunc('month', now())::date;
  v_used integer;
begin
  insert into public.usage_monthly(user_id, month_start, message_count)
  values (p_user_id, v_month, 0)
  on conflict (user_id, month_start) do nothing;

  select message_count into v_used
  from public.usage_monthly
  where user_id = p_user_id and month_start = v_month
  for update;

  if p_limit is not null and v_used >= p_limit then
    return query select false, v_used;
    return;
  end if;

  update public.usage_monthly
  set message_count = message_count + 1
  where user_id = p_user_id and month_start = v_month
  returning message_count into v_used;

  return query select true, v_used;
end;
$$;

create or replace function public.refund_message_quota(p_user_id uuid)
returns void
language sql
security definer set search_path = public
as $$
  update public.usage_monthly
  set message_count = greatest(message_count - 1, 0)
  where user_id = p_user_id
    and month_start = date_trunc('month', now())::date;
$$;


create or replace function public.activate_payos_order(
  p_order_code bigint,
  p_amount integer,
  p_reference text
)
returns boolean
language plpgsql
security definer set search_path = public
as $$
declare
  v_order public.payment_orders%rowtype;
  v_current_end timestamptz;
  v_base timestamptz;
begin
  select * into v_order
  from public.payment_orders
  where order_code = p_order_code
  for update;

  if not found or v_order.status = 'paid' or v_order.amount <> p_amount then
    return false;
  end if;

  select current_period_end into v_current_end
  from public.subscriptions
  where user_id = v_order.user_id;

  v_base := greatest(coalesce(v_current_end, now()), now());

  insert into public.subscriptions (
    user_id, status, provider, plan_id, current_period_end,
    cancel_at_period_end, updated_at
  ) values (
    v_order.user_id, 'active', 'payos', v_order.plan_id,
    v_base + make_interval(days => v_order.duration_days), false, now()
  )
  on conflict (user_id) do update set
    status = 'active',
    provider = 'payos',
    plan_id = excluded.plan_id,
    current_period_end = excluded.current_period_end,
    cancel_at_period_end = false,
    updated_at = now();

  update public.payment_orders
  set status = 'paid', provider_reference = p_reference, paid_at = now()
  where order_code = p_order_code;

  return true;
end;
$$;

revoke all on function public.consume_message_quota(uuid, integer) from public, anon, authenticated;
revoke all on function public.refund_message_quota(uuid) from public, anon, authenticated;
revoke all on function public.activate_payos_order(bigint, integer, text) from public, anon, authenticated;
grant execute on function public.consume_message_quota(uuid, integer) to service_role;
grant execute on function public.refund_message_quota(uuid) to service_role;
grant execute on function public.activate_payos_order(bigint, integer, text) to service_role;

alter table public.profiles enable row level security;
alter table public.subscriptions enable row level security;
alter table public.usage_monthly enable row level security;
alter table public.payment_orders enable row level security;
alter table public.chat_threads enable row level security;
alter table public.chat_messages enable row level security;

drop policy if exists "profiles_select_own" on public.profiles;
create policy "profiles_select_own" on public.profiles for select using (auth.uid() = id);

drop policy if exists "subscriptions_select_own" on public.subscriptions;
create policy "subscriptions_select_own" on public.subscriptions for select using (auth.uid() = user_id);

drop policy if exists "usage_select_own" on public.usage_monthly;
create policy "usage_select_own" on public.usage_monthly for select using (auth.uid() = user_id);



drop policy if exists "payment_orders_select_own" on public.payment_orders;
create policy "payment_orders_select_own" on public.payment_orders for select using (auth.uid() = user_id);

drop policy if exists "threads_all_own" on public.chat_threads;
drop policy if exists "threads_select_own" on public.chat_threads;
create policy "threads_select_own" on public.chat_threads for select using (auth.uid() = user_id);

drop policy if exists "messages_select_own" on public.chat_messages;
create policy "messages_select_own" on public.chat_messages for select using (auth.uid() = user_id);
