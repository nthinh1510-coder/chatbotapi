export type PlanId = "starter" | "pro" | "business";

export type Plan = {
  id: PlanId;
  name: string;
  priceLabel: string;
  description: string;
  amountVnd: number;
  durationDays: number;
  messageLimit: number | null;
  popular?: boolean;
  features: string[];
};

export const PLANS: Plan[] = [
  {
    id: "starter",
    name: "Starter",
    priceLabel: "199.000đ/30 ngày",
    description: "Dành cho người dùng cá nhân và nhu cầu cơ bản.",
    amountVnd: 199000,
    durationDays: 30,
    messageLimit: 500,
    features: ["500 tin nhắn/tháng", "Lưu lịch sử hội thoại", "Hỗ trợ tiêu chuẩn"],
  },
  {
    id: "pro",
    name: "Pro",
    priceLabel: "499.000đ/30 ngày",
    description: "Dành cho người dùng thường xuyên và nhóm nhỏ.",
    amountVnd: 499000,
    durationDays: 30,
    messageLimit: 2000,
    popular: true,
    features: ["2.000 tin nhắn/tháng", "Ưu tiên tốc độ xử lý", "Quản lý lịch sử nâng cao"],
  },
  {
    id: "business",
    name: "Business",
    priceLabel: "999.000đ/30 ngày",
    description: "Dành cho doanh nghiệp cần hạn mức lớn và hỗ trợ riêng.",
    amountVnd: 999000,
    durationDays: 30,
    messageLimit: null,
    features: ["Không giới hạn theo gói", "Hỗ trợ ưu tiên", "Tùy chỉnh chatbot & thương hiệu"],
  },
];

export function getPlan(planId: string | null | undefined) {
  return PLANS.find((plan) => plan.id === planId) ?? null;
}

export function getStripePriceId(planId: PlanId) {
  const map: Record<PlanId, string | undefined> = {
    starter: process.env.STRIPE_PRICE_STARTER,
    pro: process.env.STRIPE_PRICE_PRO,
    business: process.env.STRIPE_PRICE_BUSINESS,
  };
  return map[planId];
}
