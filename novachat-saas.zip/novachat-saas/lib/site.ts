export const siteConfig = {
  name: process.env.NEXT_PUBLIC_APP_NAME || "NovaChat AI",
  url: process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000",
  description: "Nền tảng chatbot AI dành cho người dùng trả phí.",
};
