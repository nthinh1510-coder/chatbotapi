import { createAdminClient } from "@/lib/supabase/admin";

const ACTIVE_STATUSES = new Set(["active", "trialing"]);

export async function getActiveSubscription(userId: string) {
  const admin = createAdminClient();
  const { data, error } = await admin
    .from("subscriptions")
    .select("*")
    .eq("user_id", userId)
    .maybeSingle();

  if (error) throw error;
  if (!data || !ACTIVE_STATUSES.has(data.status)) return null;

  if (data.current_period_end && new Date(data.current_period_end) < new Date()) {
    return null;
  }

  return data;
}
