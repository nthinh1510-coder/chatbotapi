import Link from "next/link";
import { Bot, LayoutDashboard } from "lucide-react";
import { getCurrentUser } from "@/lib/auth";
import { siteConfig } from "@/lib/site";
import { SignOutButton } from "@/components/sign-out-button";

export async function Header() {
  let user = null;
  try { user = await getCurrentUser(); } catch { user = null; }

  return (
    <header className="header">
      <div className="container header-inner">
        <Link className="brand" href="/">
          <span className="brand-mark"><Bot size={20} /></span>
          <span>{siteConfig.name}</span>
        </Link>
        <nav className="nav">
          <Link href="/#features">Tính năng</Link>
          <Link href="/pricing">Bảng giá</Link>
          <Link href="/#faq">Câu hỏi thường gặp</Link>
        </nav>
        <div className="header-actions">
          {user ? (
            <>
              <Link className="btn btn-secondary" href="/chat"><LayoutDashboard size={16}/> Vào ứng dụng</Link>
              <SignOutButton />
            </>
          ) : (
            <>
              <Link className="btn btn-secondary" href="/login">Đăng nhập</Link>
              <Link className="btn btn-primary" href="/pricing">Mua gói</Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
