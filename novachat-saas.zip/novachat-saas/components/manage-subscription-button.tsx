"use client";

import { useState } from "react";
import { CreditCard, LoaderCircle } from "lucide-react";

export function ManageSubscriptionButton() {
  const [loading, setLoading] = useState(false);
  async function openPortal() {
    setLoading(true);
    const response = await fetch("/api/portal", { method: "POST" });
    const data = await response.json();
    if (response.ok) window.location.href = data.url;
    else { alert(data.error || "Không thể mở trang quản lý"); setLoading(false); }
  }
  return <button className="btn btn-secondary btn-block" onClick={openPortal} disabled={loading}>{loading ? <LoaderCircle className="spin" size={16}/> : <CreditCard size={16}/>} Gia hạn / quản lý gói</button>;
}
