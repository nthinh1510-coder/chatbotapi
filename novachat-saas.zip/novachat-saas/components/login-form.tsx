"use client";

import { FormEvent, useState } from "react";
import { LoaderCircle } from "lucide-react";
import { createClient } from "@/lib/supabase/client";

export function LoginForm({ nextPath = "/chat" }: { nextPath?: string }) {
  const safeNext = nextPath.startsWith("/") && !nextPath.startsWith("//") ? nextPath : "/chat";
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  async function submit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    setSuccess("");
    const supabase = createClient();

    if (mode === "signup") {
      const { error: signUpError } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: { full_name: fullName },
          emailRedirectTo: `${window.location.origin}/auth/callback?next=${encodeURIComponent(safeNext)}`,
        },
      });
      if (signUpError) setError(signUpError.message);
      else setSuccess("Đăng ký thành công. Hãy kiểm tra email để xác nhận tài khoản.");
    } else {
      const { error: signInError } = await supabase.auth.signInWithPassword({ email, password });
      if (signInError) setError(signInError.message);
      else window.location.href = safeNext;
    }
    setLoading(false);
  }

  async function signInWithGoogle() {
    setLoading(true);
    setError("");
    const supabase = createClient();
    const { error: oauthError } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: `${window.location.origin}/auth/callback?next=${encodeURIComponent(safeNext)}`,
      },
    });
    if (oauthError) {
      setError(oauthError.message);
      setLoading(false);
    }
  }

  return (
    <div className="panel auth-card">
      <h1>{mode === "login" ? "Chào mừng trở lại" : "Tạo tài khoản"}</h1>
      <p>{mode === "login" ? "Đăng nhập để tiếp tục sử dụng trợ lý AI." : "Tạo tài khoản, sau đó chọn gói phù hợp."}</p>
      <button className="btn btn-secondary btn-block" onClick={signInWithGoogle} disabled={loading}>Tiếp tục với Google</button>
      <div className="divider">hoặc dùng email</div>
      <form className="form" onSubmit={submit}>
        {mode === "signup" && <div className="field"><label>Họ và tên</label><input className="input" value={fullName} onChange={(event) => setFullName(event.target.value)} required /></div>}
        <div className="field"><label>Email</label><input className="input" type="email" autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} required /></div>
        <div className="field"><label>Mật khẩu</label><input className="input" type="password" autoComplete={mode === "login" ? "current-password" : "new-password"} minLength={6} value={password} onChange={(event) => setPassword(event.target.value)} required /></div>
        {error && <div className="form-error">{error}</div>}
        {success && <div className="form-success">{success}</div>}
        <button className="btn btn-primary btn-block" disabled={loading}>{loading ? <><LoaderCircle className="spin" size={17}/> Đang xử lý</> : (mode === "login" ? "Đăng nhập" : "Đăng ký")}</button>
      </form>
      <p style={{ textAlign: "center", margin: "20px 0 0", fontSize: 14 }}>
        {mode === "login" ? "Chưa có tài khoản? " : "Đã có tài khoản? "}
        <button type="button" style={{ border: 0, background: "none", color: "#a99bff", fontWeight: 800 }} onClick={() => { setMode(mode === "login" ? "signup" : "login"); setError(""); setSuccess(""); }}>
          {mode === "login" ? "Đăng ký" : "Đăng nhập"}
        </button>
      </p>
    </div>
  );
}
