"use client";

import { LogOut } from "lucide-react";
import { createClient } from "@/lib/supabase/client";

export function SignOutButton() {
  async function signOut() {
    const supabase = createClient();
    await supabase.auth.signOut();
    window.location.href = "/";
  }

  return <button className="btn btn-secondary" onClick={signOut} aria-label="Đăng xuất"><LogOut size={16}/></button>;
}
