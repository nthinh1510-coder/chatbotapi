"use client";

import { useState } from "react";
import { Check, LoaderCircle } from "lucide-react";
import { PLANS, type PlanId } from "@/lib/plans";

export function PricingCards() {
  const [loading, setLoading] = useState<PlanId | null>(null);
  const [error, setError] = useState("");

  async function checkout(planId: PlanId) {
    setLoading(planId);
    setError("");
    try {
      const response = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ planId }),
      });

      if (response.status === 401) {
        window.location.href = "/login?next=/pricing";
        return;
      }

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Không thể tạo phiên thanh toán");
      window.location.href = data.url;
    } catch (e) {
      setError(e instanceof Error ? e.message : "Đã xảy ra lỗi");
      setLoading(null);
    }
  }

  return (
    <>
      {error && <div className="form-error" style={{ maxWidth: 700, margin: "0 auto 20px" }}>{error}</div>}
      <div className="pricing-grid">
        {PLANS.map((plan) => (
          <article key={plan.id} className={`price-card ${plan.popular ? "popular" : ""}`}>
            {plan.popular && <span className="badge">Được chọn nhiều nhất</span>}
            <h3>{plan.name}</h3>
            <div className="price">{plan.priceLabel}</div>
            <div className="price-desc">{plan.description}</div>
            <ul className="feature-list">
              {plan.features.map((feature) => (
                <li key={feature}><Check size={17} color="#78e8ae" /> {feature}</li>
              ))}
            </ul>
            <button className={`btn btn-block ${plan.popular ? "btn-primary" : "btn-secondary"}`} onClick={() => checkout(plan.id)} disabled={loading !== null}>
              {loading === plan.id ? <><LoaderCircle size={17} className="spin" /> Đang chuyển...</> : "Chọn gói này"}
            </button>
          </article>
        ))}
      </div>
    </>
  );
}
