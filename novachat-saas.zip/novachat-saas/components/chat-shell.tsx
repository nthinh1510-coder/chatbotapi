"use client";

import { FormEvent, KeyboardEvent, useEffect, useRef, useState } from "react";
import { Bot, Plus, Send, User } from "lucide-react";
import { ManageSubscriptionButton } from "@/components/manage-subscription-button";

type Thread = { id: string; title: string; updated_at: string };
type Message = { id?: string; role: "user" | "assistant"; content: string; created_at?: string };

type Props = {
  initialThreads: Thread[];
  initialThreadId: string | null;
  initialMessages: Message[];
  planName: string;
  initialUsed: number;
  messageLimit: number | null;
};

const suggestions = [
  "Tóm tắt nội dung quan trọng cho tôi",
  "Lập một kế hoạch công việc chi tiết",
  "Giải thích vấn đề theo cách dễ hiểu",
  "Đề xuất các bước tiếp theo phù hợp",
];

export function ChatShell({ initialThreads, initialThreadId, initialMessages, planName, initialUsed, messageLimit }: Props) {
  const [threads, setThreads] = useState(initialThreads);
  const [activeThreadId, setActiveThreadId] = useState<string | null>(initialThreadId);
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [used, setUsed] = useState(initialUsed);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [loadingThread, setLoadingThread] = useState(false);
  const [error, setError] = useState("");
  const endRef = useRef<HTMLDivElement>(null);

  const usageLabel = messageLimit ? `${used}/${messageLimit}` : `${used} tin`;

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, sending]);

  async function loadThread(threadId: string) {
    if (sending || loadingThread || threadId === activeThreadId) return;
    setError("");
    setLoadingThread(true);
    try {
      const response = await fetch(`/api/chat?threadId=${encodeURIComponent(threadId)}`);
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Không thể tải cuộc trò chuyện");
      setActiveThreadId(threadId);
      setMessages(data.messages || []);
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : "Không thể tải cuộc trò chuyện");
    } finally {
      setLoadingThread(false);
    }
  }

  function newChat() {
    if (sending) return;
    setActiveThreadId(null);
    setMessages([]);
    setInput("");
    setError("");
  }

  async function sendMessage(event?: FormEvent) {
    event?.preventDefault();
    const text = input.trim();
    if (!text || sending) return;

    const optimisticId = `pending-${Date.now()}`;
    setInput("");
    setError("");
    setSending(true);
    setMessages((current) => [...current, { id: optimisticId, role: "user", content: text }]);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text, threadId: activeThreadId }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Không thể gửi tin nhắn");

      setMessages((current) => [...current, { role: "assistant", content: data.answer }]);
      if (typeof data.used === "number") setUsed(data.used);

      if (!activeThreadId) {
        setActiveThreadId(data.threadId);
        setThreads((current) => [{ id: data.threadId, title: data.title, updated_at: new Date().toISOString() }, ...current]);
      } else {
        setThreads((current) => {
          const updated = current.map((thread) => thread.id === activeThreadId
            ? { ...thread, updated_at: new Date().toISOString() }
            : thread);
          return updated.sort((a, b) => b.updated_at.localeCompare(a.updated_at));
        });
      }
    } catch (sendError) {
      setMessages((current) => current.filter((message) => message.id !== optimisticId));
      setInput(text);
      setError(sendError instanceof Error ? sendError.message : "Đã xảy ra lỗi");
    } finally {
      setSending(false);
    }
  }

  function handleKeyDown(event: KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      void sendMessage();
    }
  }

  return (
    <div className="container dashboard-grid">
      <aside className="panel sidebar">
        <div className="sidebar-head"><strong>Hội thoại</strong><button className="btn btn-secondary" style={{ padding: 9 }} onClick={newChat} aria-label="Cuộc trò chuyện mới"><Plus size={17}/></button></div>
        <div className="thread-list">
          {threads.length === 0 && <div style={{ color: "#71839b", fontSize: 13, padding: 10 }}>Chưa có hội thoại.</div>}
          {threads.map((thread) => (
            <button key={thread.id} className={`thread-item ${activeThreadId === thread.id ? "active" : ""}`} onClick={() => void loadThread(thread.id)}>{thread.title}</button>
          ))}
        </div>
        <div className="sidebar-bottom">
          <div className="plan-pill"><span>Gói {planName}</span><strong>{usageLabel}</strong></div>
          <div style={{ height: 10 }}/>
          <ManageSubscriptionButton />
        </div>
      </aside>

      <section className="panel chat-panel">
        <div className="chat-top">
          <div>
            <h1>{activeThreadId ? "Trợ lý AI" : "Cuộc trò chuyện mới"}</h1>
            <span className="mobile-plan-label">Gói {planName} · {usageLabel}</span>
          </div>
          <div className="mobile-chat-controls">
            <select
              aria-label="Chọn hội thoại"
              value={activeThreadId || ""}
              onChange={(event) => event.target.value ? void loadThread(event.target.value) : newChat()}
              disabled={sending || loadingThread}
            >
              <option value="">Hội thoại mới</option>
              {threads.map((thread) => <option key={thread.id} value={thread.id}>{thread.title}</option>)}
            </select>
            <button className="btn btn-secondary" onClick={newChat} disabled={sending} aria-label="Cuộc trò chuyện mới"><Plus size={17}/></button>
          </div>
          <div className="online">{loadingThread ? "Đang tải" : "Sẵn sàng"}</div>
        </div>
        <div className="messages">
          {messages.length === 0 ? (
            <div className="empty-chat">
              <div className="brand-mark" style={{ margin: "0 auto", width: 52, height: 52 }}><Bot/></div>
              <h2>Tôi có thể giúp gì cho bạn?</h2>
              <p>Hãy đặt câu hỏi hoặc chọn một gợi ý để bắt đầu.</p>
              <div className="suggestions">
                {suggestions.map((suggestion) => <button className="suggestion" key={suggestion} onClick={() => setInput(suggestion)}>{suggestion}</button>)}
              </div>
            </div>
          ) : messages.map((message, index) => (
            <div className={`message ${message.role === "user" ? "user" : ""}`} key={message.id || `${message.role}-${index}`}>
              <div className="avatar">{message.role === "user" ? <User size={18}/> : <Bot size={18}/>}</div>
              <div className="message-content">{message.content}</div>
            </div>
          ))}
          {sending && <div className="message"><div className="avatar"><Bot size={18}/></div><div className="message-content"><div className="typing"><span/><span/><span/></div></div></div>}
          {error && <div className="form-error" style={{ maxWidth: 680 }}>{error}</div>}
          <div ref={endRef}/>
        </div>
        <form className="chat-composer" onSubmit={sendMessage}>
          <div className="composer-row">
            <textarea value={input} onChange={(event) => setInput(event.target.value)} onKeyDown={handleKeyDown} placeholder="Nhập câu hỏi..." rows={1} disabled={sending}/>
            <button className="send-btn" disabled={!input.trim() || sending} aria-label="Gửi"><Send size={19}/></button>
          </div>
          <div className="composer-note">AI có thể mắc lỗi. Hãy kiểm tra thông tin quan trọng.</div>
        </form>
      </section>
    </div>
  );
}
