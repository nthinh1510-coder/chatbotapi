import Link from "next/link";
import { siteConfig } from "@/lib/site";

export function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-inner">
        <div>© {new Date().getFullYear()} {siteConfig.name}. All rights reserved.</div>
        <div className="footer-links">
          <Link href="/terms">Điều khoản</Link>
          <Link href="/privacy">Bảo mật</Link>
          <a href="mailto:support@example.com">Hỗ trợ</a>
        </div>
      </div>
    </footer>
  );
}
