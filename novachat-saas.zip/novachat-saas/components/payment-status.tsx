"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { CheckCircle2, LoaderCircle, XCircle } from "lucide-react";

export function PaymentStatus({ orderCode }: { orderCode: string }) {
  const [status, setStatus] = useState<"checking" | "paid" | "failed">("checking");
  const [message, setMessage] = useState("Đang xác nhận giao dịch với cổng thanh toán...");

  useEffect(() => {
    let attempts = 0;
    let stopped = false;

    async function check() {
      attempts += 1;
      try {
        const response = await fetch(`/api/payment-status?orderCode=${encodeURIComponent(orderCode)}`, { cache: "no-store" });
        const data = await response.json();
        if (response.ok && data.status === "paid") {
          setStatus("paid");
          setMessage("Thanh toán thành công. Gói của bạn đã được kích hoạt.");
          setTimeout(() => { window.location.href = "/chat?payment=success"; }, 1200);
          return;
        }
        if (response.ok && ["cancelled", "expired"].includes(data.status)) {
          setStatus("failed");
          setMessage("Giao dịch đã bị hủy hoặc hết hạn.");
          return;
        }
      } catch {
        // Tiếp tục thử trong thời gian ngắn vì webhook có thể đến chậm.
      }

      if (!stopped && attempts < 15) {
        setTimeout(check, 2000);
      } else if (!stopped) {
        setStatus("failed");
        setMessage("Chưa nhận được xác nhận. Nếu tài khoản đã bị trừ tiền, hãy tải lại trang sau ít phút hoặc liên hệ hỗ trợ.");
      }
    }

    void check();
    return () => { stopped = true; };
  }, [orderCode]);

  return (
    <div className="panel" style={{ padding: 38, textAlign: "center" }}>
      {status === "checking" && <LoaderCircle className="spin" size={54} style={{ margin: "0 auto", color: "#a99bff" }} />}
      {status === "paid" && <CheckCircle2 size={54} style={{ margin: "0 auto", color: "#78e8ae" }} />}
      {status === "failed" && <XCircle size={54} style={{ margin: "0 auto", color: "#ff9eaa" }} />}
      <h1 style={{ fontSize: 36, letterSpacing: -1.2 }}>{status === "paid" ? "Đã kích hoạt" : status === "failed" ? "Chưa xác nhận" : "Đang xử lý"}</h1>
      <p style={{ color: "#9fb0c8", lineHeight: 1.7 }}>{message}</p>
      {status === "failed" && <div style={{ display: "flex", justifyContent: "center", gap: 10, flexWrap: "wrap" }}><button className="btn btn-secondary" onClick={() => window.location.reload()}>Kiểm tra lại</button><Link className="btn btn-primary" href="/pricing">Quay lại bảng giá</Link></div>}
    </div>
  );
}
